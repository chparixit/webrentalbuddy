import express from "express";
import { upload } from "../middlewares/upload";

const router = express.Router();

router.post(
  "/upload",
  upload.single("image"),
  (req, res) => {
    res.json({
      message: "Upload successful",
      filename: req.file?.filename,
      path: `/uploads/${req.file?.filename}`,
    });
  }
);

export default router;